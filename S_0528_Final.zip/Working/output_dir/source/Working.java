import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import SimpleOpenNI.*; 
import java.util.Random; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Working extends PApplet {



SimpleOpenNI context;
boolean autoCalib = true;
Random random = new Random();

// for recording
boolean isRecording = false;
int actionId = 0;
Action actionToRecord;

// for loading
Action actionLoaded;
String currentFileName;
int showId = 0;

// for showing
boolean isEcho = true;
int sessionId = 2;
ActionChooser actionChooser = getRandomChooser();
String currentSession = actionChooser.sessionName;

int startLatency = 0;

// for background drawing
boolean needRefresh = false;
PShape s; 
ArrayList ve; 
int nve = 1; 

// max length of segments 
float slen = 5.0f; 
// scale factor for the image 
float sf = 1; 
String svgFile = actionChooser.bgSvg; 

int recordIdx = 0;
int showIdx = 0;

// auto restart
int restartTimer = 0;
 

final static int RECORD_FRAME_NUM = 300;

public void setup()
{
  context = new SimpleOpenNI(this);
  // enable depthMap generation 
  if(context.enableDepth() == false)
  {
     println("Can't open the depthMap, maybe the camera is not connected!"); 
     exit();
     return;
  }
  
  // enable skeleton generation for all joints
  context.enableUser(SimpleOpenNI.SKEL_PROFILE_ALL);
  context.enableScene();
  
  // initialize data record
  actionToRecord = new Action(3000);
  actionLoaded = new Action(3000);
  currentFileName = actionChooser.firstAction;
  actionLoaded.load(currentFileName);
  
  // for background drawing
  ve = new ArrayList(); 
  s = loadShape(svgFile); 
  s.scale(sf);
  exVert(s, sf);
  
  smooth();
//  size(context.depthWidth(), context.depthHeight()); 
  size(800,800);
  frameRate(30);
  background(255);
}

public void draw()
{
  restartTimer++;
  if (restartTimer > 300) {
    println("restart");
    exit();
  }
  // update the cam
  context.update();
  context.setMirror(true);
  // draw depthImageMap
  // image(context.depthImage(),0,0, 32, 24, 50);
  //image(context.depthImage(),0,0);
  if (needRefresh) {
      background(255);
      shape(s); 
      translate(0, 150);
  }
  // record every frame, load them all in setup, use each of them to refresh

  if (needRefresh) {
    for (int i = 0; i < 5; i++){
      if(context.isTrackingSkeleton(i))
      {
        SkeletonData data = drawSkeleton(i);
        
        if (i != 1)
          continue;
          
        recordAction(actionToRecord, data);
        

        showLoadedAction(actionLoaded);
        
        startLatency++;
        if (startLatency < 1 * 30)
          continue;
        
        String filename = actionChooser.choose(data, 
                                        actionLoaded.frames[actionLoaded.currentIdx], 
                                        actionLoaded);
        if (filename != null)
        {
          actionLoaded = new Action();
          currentFileName = filename;
          actionLoaded.load(currentFileName);
        }
        
        else if (actionLoaded.currentIdx == 0)
        {
          actionLoaded = new Action(3000);
          actionChooser = getRandomChooser();
          currentFileName = actionChooser.firstAction;
          currentSession = actionChooser.sessionName;
          startLatency = 0;
          actionLoaded.load(currentFileName);
          // for background drawing
          ve = new ArrayList(); 
          nve = 0;
          s = loadShape(actionChooser.bgSvg); 
          s.scale(sf);
          exVert(s, sf);
          needRefresh = false;
          background(255);
        }     
      
      }
    }
  }
  else {
    if(nve < ve.size() && ((Point) ve.get(nve)).z != -10.0f) // a way to separate distinct paths 
    {
    stroke(186,147,216);
    strokeWeight(4);
    line(((Point) ve.get(nve-1)).x, ((Point) ve.get(nve-1)).y, 
        ((Point) ve.get(nve)).x, ((Point) ve.get(nve)).y); 
  //  ellipse( ((Point) ve.get(nve)).x, ((Point) ve.get(nve)).y, 2, 2 ); 
    }
    nve++;
    if(nve < ve.size() && ((Point) ve.get(nve)).z != -10.0f) // a way to separate distinct paths 
    {
    stroke(186,147,216);
    strokeWeight(4);
    line(((Point) ve.get(nve-1)).x, ((Point) ve.get(nve-1)).y, 
        ((Point) ve.get(nve)).x, ((Point) ve.get(nve)).y); 
  //  ellipse( ((Point) ve.get(nve)).x, ((Point) ve.get(nve)).y, 2, 2 ); 
    }
    nve++;
    if(nve < ve.size() && ((Point) ve.get(nve)).z != -10.0f) // a way to separate distinct paths 
    {
    stroke(186,147,216);
    strokeWeight(4);
    line(((Point) ve.get(nve-1)).x, ((Point) ve.get(nve-1)).y, 
        ((Point) ve.get(nve)).x, ((Point) ve.get(nve)).y); 
  //  ellipse( ((Point) ve.get(nve)).x, ((Point) ve.get(nve)).y, 2, 2 ); 
    }
    nve++;
    if(nve < ve.size() && ((Point) ve.get(nve)).z != -10.0f) // a way to separate distinct paths 
    {
    stroke(186,147,216);
    strokeWeight(4);
    line(((Point) ve.get(nve-1)).x, ((Point) ve.get(nve-1)).y, 
        ((Point) ve.get(nve)).x, ((Point) ve.get(nve)).y); 
  //  ellipse( ((Point) ve.get(nve)).x, ((Point) ve.get(nve)).y, 2, 2 ); 
    }
    nve++;
    if(nve < ve.size() && ((Point) ve.get(nve)).z != -10.0f) // a way to separate distinct paths 
    {
    stroke(186,147,216);
    strokeWeight(4);
    line(((Point) ve.get(nve-1)).x, ((Point) ve.get(nve-1)).y, 
        ((Point) ve.get(nve)).x, ((Point) ve.get(nve)).y); 
  //  ellipse( ((Point) ve.get(nve)).x, ((Point) ve.get(nve)).y, 2, 2 ); 
    }
    nve++;
    if (nve >= ve.size()) {
      needRefresh = true;
      s = loadShape(actionChooser.bgOutline);
    }
  }
  
}

public void keyPressed()
{
  if (key == 'b')
  {
    isRecording = true;
    println("Begin recording");
  }
  else if (key == 'e')
  {
    isRecording= false;
    actionToRecord.finishAndRecord("SavedAction_" + actionId + ".txt");
    actionId++;
    actionToRecord = new Action();
    println("End recording");
  }
  else if (key == 'c')
  {
    actionLoaded = new Action();
    String filename = dataPath("SavedAction_" + showId + ".txt");
    showId++;
    actionLoaded.load(filename);
  }
}

public ActionChooser getRandomChooser(){
  sessionId = (sessionId + 1) % 3;
  if (sessionId == 0)
    return new ActionChooserDance();
  if (sessionId == 1)
    return new ActionChooserFight();
  if (sessionId == 2)
    return new ActionChooserSad();
  return new ActionChooserDance();
}

public void recordAction(Action action, SkeletonData data)
{
  if (!isRecording)
    return;
    
  int result = action.addFrame(data);
  // finish recording because don't have place for more frames
  if (result == -1)
  {
    isRecording = false;
    action.finishAndRecord("SavedAction_" + actionId + ".txt");
    actionId++;
    actionToRecord = new Action();
    println("End recording");
  }
}

public void showLoadedAction(Action action)
{
  // show loaded action
  SkeletonData data = action.frames[action.currentIdx];
  drawSkeletonData(data);
  action.currentIdx = (action.currentIdx + 1) % action.frameNum;
}

public void drawSkeletonData(SkeletonData data)
{
  PVector[] vecs = data.vectors;
  fill(0xff3B3B52, 200); // color of sticckman
  noStroke();
  if (vecs[0].x != 0 && vecs[0].y != 0)
  {
    ellipse(vecs[0].x, vecs[0].y, 50, 50);
  }
  
  noFill();
  stroke(0xff3B3B52, 200);
  strokeWeight(16);
  
  myCurve(vecs[2].x, vecs[2].y, vecs[3].x, vecs[3].y, vecs[16].x, vecs[16].y);
  myCurve(vecs[5].x, vecs[5].y, vecs[6].x, vecs[6].y, vecs[15].x, vecs[15].y);
  myCurve(vecs[8].x, vecs[8].y, vecs[9].x, vecs[9].y, vecs[11].x, vecs[11].y);
  myCurve(vecs[10].x, vecs[10].y, vecs[12].x, vecs[12].y, vecs[14].x, vecs[14].y);
  myCurve(vecs[1].x, vecs[1].y, vecs[2].x, vecs[2].y, vecs[5].x, vecs[5].y);
  myCurve(vecs[2].x, vecs[2].y, vecs[7].x, vecs[7].y, vecs[10].x, vecs[10].y);
  myCurve(vecs[5].x, vecs[5].y, vecs[7].x, vecs[7].y, vecs[8].x, vecs[8].y);
}

public void myCurve(float x1, float y1, float x2, float y2, float x3, float y3)
{
  if (x1 == 0 && y1 == 0 || x2 == 0 && y2 == 0 || x3 ==0 && y3 == 0)
    return;
  beginShape();
  curveVertex(x1, y1);
  curveVertex(x1, y1);
  curveVertex(x2, y2);
  curveVertex(x3, y3);
  curveVertex(x3, y3);
  endShape();
}

// draw the skeleton with the selected joints
public SkeletonData drawSkeleton(int userId)
{
  if (userId == 1)
    stroke(0xffF576AD, 200); // color of user
  else
    stroke(123, 63);
  strokeCap(ROUND);
  strokeJoin(ROUND);
  strokeWeight(16);
  
  /*
  context.drawLimb(userId, SimpleOpenNI.SKEL_HEAD, SimpleOpenNI.SKEL_NECK);
  context.drawLimb(userId, SimpleOpenNI.SKEL_NECK, SimpleOpenNI.SKEL_LEFT_SHOULDER);
  context.drawLimb(userId, SimpleOpenNI.SKEL_LEFT_SHOULDER, SimpleOpenNI.SKEL_LEFT_ELBOW);
  context.drawLimb(userId, SimpleOpenNI.SKEL_LEFT_ELBOW, SimpleOpenNI.SKEL_LEFT_HAND);

  context.drawLimb(userId, SimpleOpenNI.SKEL_NECK, SimpleOpenNI.SKEL_RIGHT_SHOULDER);
  context.drawLimb(userId, SimpleOpenNI.SKEL_RIGHT_SHOULDER, SimpleOpenNI.SKEL_RIGHT_ELBOW);
  context.drawLimb(userId, SimpleOpenNI.SKEL_RIGHT_ELBOW, SimpleOpenNI.SKEL_RIGHT_HAND);

  context.drawLimb(userId, SimpleOpenNI.SKEL_LEFT_SHOULDER, SimpleOpenNI.SKEL_TORSO);
  context.drawLimb(userId, SimpleOpenNI.SKEL_RIGHT_SHOULDER, SimpleOpenNI.SKEL_TORSO);

  context.drawLimb(userId, SimpleOpenNI.SKEL_TORSO, SimpleOpenNI.SKEL_LEFT_HIP);
  context.drawLimb(userId, SimpleOpenNI.SKEL_LEFT_HIP, SimpleOpenNI.SKEL_LEFT_KNEE);
  context.drawLimb(userId, SimpleOpenNI.SKEL_LEFT_KNEE, SimpleOpenNI.SKEL_LEFT_FOOT);

  context.drawLimb(userId, SimpleOpenNI.SKEL_TORSO, SimpleOpenNI.SKEL_RIGHT_HIP);
  context.drawLimb(userId, SimpleOpenNI.SKEL_RIGHT_HIP, SimpleOpenNI.SKEL_RIGHT_KNEE);
  context.drawLimb(userId, SimpleOpenNI.SKEL_RIGHT_KNEE, SimpleOpenNI.SKEL_RIGHT_FOOT);
  */
  drawCurve(userId, SimpleOpenNI.SKEL_LEFT_SHOULDER, SimpleOpenNI.SKEL_NECK, SimpleOpenNI.SKEL_RIGHT_SHOULDER);
  drawCurve(userId, SimpleOpenNI.SKEL_LEFT_SHOULDER, SimpleOpenNI.SKEL_TORSO, SimpleOpenNI.SKEL_RIGHT_HIP);
  drawCurve(userId, SimpleOpenNI.SKEL_RIGHT_SHOULDER, SimpleOpenNI.SKEL_TORSO, SimpleOpenNI.SKEL_LEFT_HIP);
  drawCurve(userId, SimpleOpenNI.SKEL_LEFT_SHOULDER, SimpleOpenNI.SKEL_LEFT_ELBOW, SimpleOpenNI.SKEL_LEFT_HAND);
  drawCurve(userId, SimpleOpenNI.SKEL_RIGHT_SHOULDER, SimpleOpenNI.SKEL_RIGHT_ELBOW, SimpleOpenNI.SKEL_RIGHT_HAND);
  drawCurve(userId, SimpleOpenNI.SKEL_LEFT_HIP, SimpleOpenNI.SKEL_LEFT_KNEE, SimpleOpenNI.SKEL_LEFT_FOOT);
  drawCurve(userId, SimpleOpenNI.SKEL_RIGHT_HIP, SimpleOpenNI.SKEL_RIGHT_KNEE, SimpleOpenNI.SKEL_RIGHT_FOOT);
  
  SkeletonData data = new SkeletonData();
  drawJoint1(userId, SimpleOpenNI.SKEL_HEAD);
  data.vectors[0] = drawJoint(userId, SimpleOpenNI.SKEL_HEAD);
  data.vectors[1] = drawJoint(userId, SimpleOpenNI.SKEL_NECK);
  data.vectors[2] = drawJoint(userId, SimpleOpenNI.SKEL_LEFT_SHOULDER);
  data.vectors[3] = drawJoint(userId, SimpleOpenNI.SKEL_LEFT_ELBOW);
  data.vectors[4] = drawJoint(userId, SimpleOpenNI.SKEL_NECK);
  data.vectors[5] = drawJoint(userId, SimpleOpenNI.SKEL_RIGHT_SHOULDER);
  data.vectors[6] = drawJoint(userId, SimpleOpenNI.SKEL_RIGHT_ELBOW);
  data.vectors[7] = drawJoint(userId, SimpleOpenNI.SKEL_TORSO);
  data.vectors[8] = drawJoint(userId, SimpleOpenNI.SKEL_LEFT_HIP);  
  data.vectors[9] = drawJoint(userId, SimpleOpenNI.SKEL_LEFT_KNEE);
  data.vectors[10] = drawJoint(userId, SimpleOpenNI.SKEL_RIGHT_HIP);  
  data.vectors[11] = drawJoint(userId, SimpleOpenNI.SKEL_LEFT_FOOT);
  data.vectors[12] = drawJoint(userId, SimpleOpenNI.SKEL_RIGHT_KNEE);
  data.vectors[13] = drawJoint(userId, SimpleOpenNI.SKEL_LEFT_HIP);  
  data.vectors[14] = drawJoint(userId, SimpleOpenNI.SKEL_RIGHT_FOOT);
  data.vectors[15] = drawJoint(userId, SimpleOpenNI.SKEL_RIGHT_HAND);
  data.vectors[16] = drawJoint(userId, SimpleOpenNI.SKEL_LEFT_HAND);
  return data;
} // end of SkeletonData drawSkeleton

public void drawCurve(int userId, int jointID1, int jointID2, int jointID3) {
  PVector joint1 = new PVector();
  PVector joint2 = new PVector();
  PVector joint3 = new PVector();
  float confidence1 = context.getJointPositionSkeleton(userId, jointID1, joint1);
  float confidence2 = context.getJointPositionSkeleton(userId, jointID2, joint2);
  float confidence3 = context.getJointPositionSkeleton(userId, jointID3, joint3);
  if(confidence1 < 0.5f || confidence2 < 0.5f ||confidence3 < 0.5f ){
    return;
  }
  PVector convertedJoint1 = new PVector();
  PVector convertedJoint2 = new PVector();
  PVector convertedJoint3 = new PVector();
  context.convertRealWorldToProjective(joint1, convertedJoint1);
  context.convertRealWorldToProjective(joint2, convertedJoint2);
  context.convertRealWorldToProjective(joint3, convertedJoint3);
  
//  if (x1 == 0 && y1 == 0 || x2 == 0 && y2 == 0 || x3 ==0 && y3 == 0)
//    return;
  beginShape();
  curveVertex(convertedJoint1.x, convertedJoint1.y);
  curveVertex(convertedJoint1.x, convertedJoint1.y);
  curveVertex(convertedJoint2.x, convertedJoint2.y);
  curveVertex(convertedJoint3.x, convertedJoint3.y);
  curveVertex(convertedJoint3.x, convertedJoint3.y);
  endShape();
  
}
public void drawJoint1(int userId, int jointID) {
  PVector joint = new PVector();
  float confidence = context.getJointPositionSkeleton(userId, jointID, joint);
  if(confidence < 0.5f){
    return;
  }
  PVector convertedJoint = new PVector();
  context.convertRealWorldToProjective(joint, convertedJoint);
  if (userId == 1)
    fill(0xffF576AD, 200); // color of user's head
  else
    fill(123, 63);
  noStroke();
  ellipse(convertedJoint.x, convertedJoint.y, 50, 50);
}
  
public PVector drawJoint(int userId, int jointID) {
  PVector joint = new PVector();
  float confidence = context.getJointPositionSkeleton(userId, jointID, joint);
  if(confidence < 0.5f){
    return null;
  }
  PVector convertedJoint = new PVector();
  context.convertRealWorldToProjective(joint, convertedJoint);
  fill(255, 20);
  noStroke();  
  ellipse(convertedJoint.x, convertedJoint.y, 12, 12);
  return convertedJoint;
}
// ---------------------

// -----------------------------------------------------------------
// SimpleOpenNI events

public void onNewUser(int userId)
{
  println("onNewUser - userId: " + userId);
  println("  start pose detection");
  
  if(autoCalib)
    context.requestCalibrationSkeleton(userId,true);
  else    
    context.startPoseDetection("Psi",userId);
}

public void onLostUser(int userId)
{
  println("onLostUser - userId: " + userId);
}

public void onStartCalibration(int userId)
{
  println("onStartCalibration - userId: " + userId);
}

public void onEndCalibration(int userId, boolean successfull)
{
  println("onEndCalibration - userId: " + userId + ", successfull: " + successfull);
  
  if (successfull) 
  { 
    println("  User calibrated !!!");
    context.startTrackingSkeleton(userId); 
  } 
  else 
  { 
    println("  Failed to calibrate user !!!");
    println("  Start pose detection");
    context.startPoseDetection("Psi",userId);
  }
}

public void onStartPose(String pose,int userId)
{
  println("onStartPose - userId: " + userId + ", pose: " + pose);
  println(" stop pose detection");
  
  context.stopPoseDetection(userId); 
  context.requestCalibrationSkeleton(userId, true);
 
}

public void onEndPose(String pose,int userId)
{
  println("onEndPose - userId: " + userId + ", pose: " + pose);
}

// for background drawing
public void exVert(PShape s, float sf) { 
  PShape[] ch; // children 
  int n, i; 
  
  n = s.getChildCount(); 
  if (n > 0) {
    for (i = 0; i < n; i++) { 
      ch = s.getChildren(); 
      exVert(ch[i], sf); 
      }
  }
  else { // no children -> work on vertex 
    n = s.getVertexCount(); 
    //println("vertex count: " + n + " getFamily():" + s.getFamily()+ " isVisible():" + s.isVisible()); 
    for (i = 0; i < n; i++) {
    float x = s.getVertexX(i)*sf; 
    float y = s.getVertexY(i)*sf; 
    // println(i + ") getVertexCode:"+s.getVertexCode(i)); 
      if (i>0) {
        float ox = s.getVertexX(i-1)*sf; 
        float oy = s.getVertexY(i-1)*sf; 
        stepToVert(ox, oy, x, y, slen); 
      }
      else {
      ve.add(new Point(x, y, -10.0f)); 
      }
    } //  end of for
  } // end of else
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
// fill in with points, if needed, from (ox, oy) to (x, y) 
// 
public void stepToVert(float ox, float oy, float x, float y, float slen) { 

  int i; 
  float n; 
  float dt = dist(ox, oy, x, y); 
  if ( dt > slen) {
    n = floor(dt/slen); 
    // println("Adding "+n+" points..."); 
    for (i = 0; i < n; i++) {
      float nx = lerp(ox, x, (i+1)/(n+1)); 
      float ny = lerp(oy, y, (i+1)/(n+1)); 
      ve.add(new Point(nx, ny, 0)); 
    } 
  }
  ve.add(new Point(x, y, 0)); 
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
// myClass for a 3D point 
// 
class Point {
  float x, y, z; 
  Point(float x, float y, float z) {
    this.x = x; 
    this.y = y; 
    this.z = z; 
  } 
  
  public void set(float x, float y, float z) {
    this.x = x; 
    this.y = y; 
    this.z = z; 
  } 
} 
class Action
{
  public SkeletonData frames[];
  public int frameNum;
  public int currentIdx;
  public String actionName;
  private int maxFrameNum;
  
  public Action()
  {
    frameNum = 0;
    currentIdx = 0;
    maxFrameNum = 3000;
    frames = new SkeletonData[maxFrameNum];
  }
  
  public Action(int maxFrameNum)
  {
    frameNum = 0;
    currentIdx = 0;
    this.maxFrameNum = maxFrameNum;
    frames = new SkeletonData[this.maxFrameNum];
  }
  
  public int addFrame(SkeletonData data)
  {
    if (currentIdx >= maxFrameNum)
    {
      println("Too much frames!!!");
      return -1;
    }
    frames[currentIdx] = data;
    currentIdx++;
    return 0;
  }
  
  public void finishAndRecord(String filename)
  {
    frameNum = currentIdx;
    String[] skeletonTexts = new String[frameNum];
    for (int i = 0; i < frameNum; i++)
    {
      skeletonTexts[i] = frames[i].toString();
    }
    String filepath = dataPath(filename);
    saveStrings(filepath, skeletonTexts);
  }
  
  public void load(String filename)
  {
    String filepath = dataPath(filename);
    String[] lines = loadStrings(filepath);
    currentIdx = 0;
    for (String line : lines)
    {
      addFrame(new SkeletonData(line));
    }
    frameNum = currentIdx;
    currentIdx = 0;
    actionName = filename;
  }
}
class ActionChooser
{
  public ActionChooser()
  {
    history = new int[10];
    historyBool = new boolean[10];

    for (int i = 0; i < 10; i++)
    {
      history[i] = 0;
      historyBool[i] = false;
    }
  }
  
  public int[] history;
  public boolean[] historyBool;

  public String firstAction;
  public String sessionName;
  public String bgSvg;
  public String bgOutline;
  
  public String choose(SkeletonData data, SkeletonData showData, Action currentAction)
  {
    return null;
  } // end of String chooose
}
class ActionChooserDance extends ActionChooser
{
  public int[] danceNUM;
  public int[] danceTime;
  public boolean[] danceBool;
  public int danceAction = 0;
  public int successNum = 0;
  public boolean isTeaching = false;
  public ActionChooserDance()
  {
    firstAction = "dance_int.txt";
    sessionName = "Dance";
    bgSvg = "dance-800.svg";
    bgOutline = "dance-outline.svg";
    danceNUM = new int[10];
    danceTime = new int[10];
    danceBool = new boolean[10];
    for (int i = 0; i < 10; i++)
    {
      danceNUM[i] = 0;
      danceTime[i] = 0;
      danceBool[i] = false;
    }
  }

  public String choose(SkeletonData data, SkeletonData showData, Action currentAction)
  {
    if (data == null)
      return null;
      
    PVector[] vecs = data.vectors;
    for (int i = 0; i < 17; i++)
    {
      if (vecs[i] == null)
        if (i == 0)
          vecs[i] = new PVector(500, 500, 2422);
        else
          vecs[i] = vecs[i - 1];
    }
    
    /*
    history:
    0: teaching time
    1: feet close time
    2: raise hand time
    */
    
    // results
    if (currentAction.currentIdx == 0) {
      if (isTeaching) {
        if (danceAction == 0) {
          float fA0 = random(0,7);
          int iA0 = PApplet.parseInt(fA0);
          switch(iA0) {
            case 0: return "dance_A0_head_a0_me_invite.txt";
            case 1: return "dance_A0_head_no_me_a0_you.txt";
            case 2: return "dance_A0_hip_no_me_a0_invite_two.txt";
            case 3: return "dance_A0_me_a0_invite_two.txt";
            case 4: return "dance_A0_me_a0_invite.txt";
            case 5: return "dance_A0_no_me_a0_invite.txt";
            case 6: return "dance_A0_no_two_a0_you.txt";
            default: return "dance_A0_no_two_a0_you.txt";
          }
        }
        if (danceAction == 1) {
          float fA1 = random(0,7);
          int iA1 = PApplet.parseInt(fA1);
          switch(iA1) {
            case 0: return "dance_A1_head_me_at_invite.txt";
            case 1: return "dance_A1_head_no_a1_me_you_two.txt";
            case 2: return "dance_A1_hips_no_a1_you_two.txt";
            case 3: return "dance_A1_me_a1_invite_two.txt";
            case 4: return "dance_A1_me_a1_invite.txt";
            case 5: return "dance_A1_no_me_a1_invite_two.txt";
            case 6: return "dance_A1_no_two_me_a1_you.txt";
            default: return "dance_A1_no_two_me_a1_you.txt";
          }
        }
        if (danceAction == 2) {
          float fA1 = random(0,7);
          int iA1 = PApplet.parseInt(fA1);
          switch(iA1) {
            case 0: return "dance_A2_me_a2_invite_two.txt";
            case 1: return "dance_A2_me_a2_invite.txt";
            case 2: return "dance_A2_no_me_a2_invite.txt";
            case 3: return "dance_A2_no_me_invite_two.txt";
            case 4: return "dance_A2_fold_no_me_a2_you.txt";
            case 5: return "dance_A2_hip_a2_me_you.txt";
            case 6: return "dance_A2_hip_no_me_a2_you.txt";
            default: return "dance_A2_sigh_me_a2_invite_two.txt";
          }
        }
        if (danceAction == 3) {
          float fA1 = random(0,7);
          int iA1 = PApplet.parseInt(fA1);
          switch(iA1) {
            case 0: return "dance_A5_fold_no_a5_invite.txt";
            case 1: return "dance_A5_hip_me_squat_a5_you.txt";
            case 2: return "dance_A5_invite_a5_invite.txt";
            case 3: return "dance_A5_invite_two_a5_you.txt";
            case 4: return "dance_A5_me_squat_a5_you.txt";
            case 5: return "dance_A5_no_me_a5_you.txt";
            case 6: return "dance_A5_warm_me_a5_invite.txt";
            default: return "dance_A5_warm_me_a5_you.txt";
          }
        }
      }
      else {
        isTeaching = true;
        switch (danceAction) {
          case 0: return "dance_a0_left_right.txt";
          case 1: return "dance_a1_raise_hand_back.txt";
          case 2: return "dance_a2_kick.txt";
          case 3: return "dance_a5_squat_outward_left_right_back.txt";
          default: if (successNum == 0)
                     return "dance_g_happy_0.txt";
                   else if (successNum == 4)
                     return "dance_g_happy_1.txt";
                   else
                     return "dance_g_happy_2.txt";
        }
      }
    }
    
    
    // =============== Dance ======================
    // --------------- a0 ------------ danceTime[0][10], danceBool[0], danceNUM[0]
    if (danceAction == 0 && isTeaching) {
      history[0]++;

      float feetdistance = abs(vecs[11].x - vecs[14].x);
//      println("feetdistance: " + feetdistance);
      if (feetdistance < 20){
        historyBool[1] = true; // if feet meet
      }
      if (historyBool[1]== true) {
        history[1]++;
      }
      if (history[1] > 30){
        history[1] = 0;
        historyBool[1] = false;
      }
      
      if (historyBool[1] == true && feetdistance > 80) {
        danceNUM[0]++;
        clearAllStates();
      }
      
      if (danceNUM[0] >= 4){
        successNum++;
        danceAction++;
        clearAllStates();
        isTeaching = false;
        return "dance_clap.txt";
      }
      else if (history[0] > 400)
      {
        danceAction++;
        clearAllStates();
        isTeaching = false;
        return "dance_g_shrug.txt";
      }
    } // end of a0
    // ------------------ a1 rasise hand ----------- danceNUM[1], danceTimep[1]
//    if (danceAction == 0) { // for test
    if (danceAction == 1 && isTeaching) {
      history[0]++;
      
      if (vecs[0].y - vecs[16].y > 50){
        history[2]++;
      }
      else {
        history[2] = 0;
      }
      
      float hand_head_distance = vecs[0].y - vecs[16].y;
      float hand_elbow_distance = vecs[3].y - vecs[16].y;
      if (history[2] > 60 && 
          450 < vecs[0].x && vecs[0].x < 550 &&
          hand_head_distance > hand_elbow_distance * 0.8f &&
          vecs[15].y > vecs[7].y
          ) {
        successNum++;
        danceAction++;
        clearAllStates();
        isTeaching = false;
        return "dance_A1_b_turn_around.txt";
      }
      else if (history[0] > 400)
      {
        // more than 40s, matchman goes alway
        danceAction++;
        clearAllStates();
        isTeaching = false;
        return "dance_g_shrug.txt";
      }
      
    } // end of a1
// ------------------ a2 kick ----------- danceTimep[2]
//    if (danceAction == 0) { // for test
    if (danceAction == 2 && isTeaching) {
      history[0]++;
      if (450 < vecs[0].x && vecs[0].x < 550 && // in certain area
          vecs[7].y < vecs[16].y && vecs[16].y < vecs[8].y && // hand between hip and torso
          vecs[2].x - vecs[3].x > 30 // left elbow away from left shoulder
          ) {
        history[2]++;
      }
      else {
        history[2] = 0;
      }
      
      if (history[2] > 60) {
        successNum++;
        danceAction++;
        clearAllStates();
        isTeaching = false;
        return "dance_A2_b_kick.txt";
      }
      else if (history[0] > 400) {
        // more than 40s, matchman goes alway
        danceAction++;
        clearAllStates();
        isTeaching = false;
        return "dance_g_shrug.txt";
      }
    }

    // ------------------ a5 squat two ----------- danceTimep[5]
//    if (danceAction == 0) { // for test
    if (danceAction == 3 && isTeaching) {
      history[0]++;
      float knees_distance = vecs[12].x - vecs[9].x;
      float right_shoulder = vecs[5].y - vecs[15].y;
      float elbow_hand = vecs[6].x - vecs[15].x;
      float neck_torso = vecs[1].x - vecs[7].x;
      if (450 < vecs[0].x && vecs[0].x < 550 && // in certain area
          vecs[0].y > 130 && // squat
          abs(vecs[12].x - vecs[9].x) > 120 && // two knees outward
          vecs[5].y > vecs[15].y && // raise right hand
          vecs[6].x > vecs[15].x && // right elbow out of right hand
          vecs[1].x > vecs[7].x // neck out of torso
          ) {
        successNum++;
        danceAction++;
        clearAllStates();
        isTeaching = false;
        return "dance_A5_b_squat_rigtht_left.txt";
      }
      else if (danceTime[5] > 400)
      {
        // more than 40s, matchman goes alway
        danceAction++;
        clearAllStates();
        isTeaching = false;
        return "dance_g_shrug.txt";
      }
    }

     return null;
  } // end of String chooose
  
  private void clearAllStates() {
    for (int i = 0; i < 10; i++)
    {
      history[i] = 0;
      historyBool[i] = false;
    }
  }
}
class ActionChooserFight extends ActionChooser
{
  public int maxTired = 90;
  public int tired = 0;
  public int hitNum = 0;
  public int getHitNum = 0;
  public int hitId = 0;
  public boolean isBeingHitting = false;
  
  public ActionChooserFight()
  {
    firstAction = "fight_int.txt";
    sessionName = "Fight";
    bgSvg = "boxing-800.svg";
    bgOutline = "boxing-outline.svg";
  }
  /*
  history:
  0: not use
  1: left hand close to left shoulder
  2: right hand close to right shoulder
  3: left hand punched
  4: right hand punched
  5: feet on floor
  */

  
  public String choose(SkeletonData data, SkeletonData showData, Action currentAction)
  {
    if (data == null)
      return null;
      
    PVector[] vecs = data.vectors;
    for (int i = 0; i < 17; i++)
    {
      if (vecs[i] == null)
        if (i == 0)
          vecs[i] = new PVector(500, 500, 2422);
        else
          vecs[i] = vecs[i - 1];
    }
    println(hitNum + " " + getHitNum + " " + tired);
    
    // get results
    if (currentAction.currentIdx == 0) {
      if (tired > 270 || currentAction.actionName.equals("fight_b_surrend.txt") || currentAction.actionName.equals("fight_a_victory.txt"))
        return null;
      if (isBeingHitting && getHitNum > 5) {
        return "fight_b_surrend.txt";
      }
      else if (hitNum > 5)
        return "fight_a_victory.txt";
      isBeingHitting = false;
      return "fight_b_guard_sway.txt";
    }
    
    
    // positive
    // ------------- b: be hit ----------- fightBool[1], fightNUM[1]
    if (!isBeingHitting && vecs[0].x < 550) {
      // if left hand near left shoulder 
      if (abs(vecs[2].x - vecs[16].x) < 40) {
        historyBool[1] = true;
      }
      if (historyBool[1] == true) {
        history[1]++;
      }
      if (history[1] >= 30) {
        historyBool[1] = false;
        history[1] = 0;
      }
      
      // if right hand near right shoulder
      if  (abs(vecs[5].x - vecs[15].x) < 40) {
        historyBool[2] = true;
      }
      if (historyBool[2] == true)
        history[2]++;
      if (history[2] >= 30) {
        historyBool[2] = false;
        history[2] = 0;
      }
      
      // recognize punching
      if (historyBool[1] == true &&
          (vecs[2].x - vecs[16].x > 100)) {// punch left fist
          historyBool[3] = true;
          getHitNum++;
          isBeingHitting = true;
          tired = 0;
      }
      else if (historyBool[2] == true &&
          (vecs[5].x - vecs[15].x > 100)) {
          getHitNum++;
          historyBool[4] = true;
          isBeingHitting = true;
          tired = 0;
      }
      
      // if user punches
      if (historyBool[3] == true || historyBool[4] == true) {
        // ----- be hit stomatch -------
        if ((historyBool[3] == true && vecs[16].y > 240) || 
            (historyBool[4] == true && vecs[15].y > 240)) {
          clearAllStates();
          float fHitStomach = random(0,2);
          int iHitStomach = PApplet.parseInt(fHitStomach);
          // response randomly
          if (iHitStomach == 0) {
            return "fight_b_be_kicked_stomach.txt";
          }
          if (iHitStomach == 1) {
            return "fight_b_dodge_left_one_hand_up.txt";
          }
        } // end be hit stomach
        
        // ----- be hit head ------
        else if ((historyBool[3] == true && vecs[16].y <= 240) || 
                 (historyBool[4] == true && vecs[15].y <= 240)) {
          clearAllStates();
          float fHitHead = random(0,4);
          int iHitHead = PApplet.parseInt(fHitHead);
          if (iHitHead == 0) 
          {
            return "fight_b_high_guard.txt";
          }
          if (iHitHead == 1) 
          {
            return "fight_b_be_hit_turning.txt";
          }
          if (iHitHead == 2) 
          {
            return "fight_b_be_hit_turning_2.txt";
          }
          if (iHitHead == 3) 
          {
            return "fight_b_be_hit_head_up.txt";
          }
        } // end be hit head
      }// end of be punched
    

    
      // ---------------- b: be kicked ------------- fightNUM[4]
      // feet on the ground
      if (abs(vecs[11].y - vecs[14].y) < 20) {
        historyBool[5] = true;
      }
      if (historyBool[5] == true) {
        history[5]++;
      }
      if (history[5] > 30) {
        historyBool[5] = false;
        history[5] = 0;
      }
    
      // if user kicks
      if (historyBool[5] == true &&
          abs(vecs[14].x - vecs[11].x) > 1.5f * abs(vecs[5].x - vecs[2].x) && // two feet wider than shoulders
           (vecs[11].y < vecs[14].y && vecs[11].x < vecs[14].x || // kick left foot
            vecs[11].y > vecs[14].y && vecs[11].x > vecs[14].x) // kick right foot
         ) {
        // low kick
        if (abs(vecs[14].y - vecs[11].y) > abs(vecs[1].y - vecs[0].y)/2 &&
            abs(vecs[14].y - vecs[11].y) < abs(vecs[1].y - vecs[0].y)) {
          getHitNum++; // record how many times matchman be hit
          isBeingHitting = true;
          tired = 0;
          clearAllStates();
          float fLowKick = random(0,4);
          int iLowKick = PApplet.parseInt(fLowKick);
          // response randomly
          if (iLowKick == 0)
          {
            return "fight_b_LowKick_grab_ankle.txt";
          }
          if (iLowKick == 1)
          {
            return "fight_b_LowKick_jump_back_one_leg.txt";
          }
          if (iLowKick == 2)
          {
            return "fight_b_LowKick_jump_back.txt";
          }
          if (iLowKick == 3)
          {
            return "fight_b_LowKick_onKnee.txt";
          }
        } // end of low kick
        // high kick 
        else if (abs(vecs[14].y - vecs[11].y) > abs(vecs[1].y - vecs[0].y))
        {
          getHitNum++; // record how many times matchman be hit
          isBeingHitting = true;
          tired = 0;
          clearAllStates();
          float fHighKick = random(0,5);
          int iHighKick = PApplet.parseInt(fHighKick);
          // response randomly
          if (iHighKick == 0)
          {
            return "fight_b_HighKick_fly_ground.txt";
          }
          if (iHighKick == 1)
          {
            return "fight_b_HighKick_ground_legs_2.txt";
          }
          if (iHighKick == 2)
          {
            return "fight_b_HighKick_ground_legs_3.txt";
          }
          if (iHighKick == 3)
          {
            return "fight_b_HighKick_ground_legs.txt";
          }
          if (iHighKick == 4)
          {
            return "fight_b_HighKick_side_one_leg.txt";
          }
        }
      } // end of kick
    } // end of be hitting

    
    // negative
    
    if (currentAction.actionName.equals("fight_b_guard_sway.txt")) {
      tired++;
      if (tired > maxTired) {
        if (400 < vecs[11].x && vecs[14].x < 600) {
          hitNum++;
          tired = 0;
          hitId = (hitId + 1)% 4;
          if (hitId == 0)
            return "fight_a_deep_one_leg_squat.txt";
          else if (hitId == 1)
            return "fight_a_turning_kick.txt";
          else if (hitId == 2)
            return "fight_a_squat_jab.txt";
          else 
            return "fight_a_high_kick.txt";          
        }
      }
    }
    
    return null;
  }
  
  private void clearAllStates() {
    for (int i = 0; i < 10; i++)
    {
      history[i] = 0;
      historyBool[i] = false;
    }
  }
}
class ActionChooserHappy extends ActionChooser
{
  public ActionChooserHappy()
  {
    firstAction = "happy_0.txt";
    sessionName = "Happy";
    bgSvg = "happy-800.svg";
    bgOutline = "happy-outline.svg";
  }
  
  public String choose(SkeletonData data, SkeletonData showData, Action currentAction)
  {
    if (data == null)
      return null;
      
    PVector[] vecs = data.vectors;
    for (int i = 0; i < 17; i++)
    {
      if (vecs[i] == null)
        return null;
    }
    /*
    // making decision
    if (vecs[2].x - vecs[16].x > 100)
    {
//      return "Fight_1.txt";
      return "happy_3.txt";
    }
    else 
      return null;
    */
    
    // wave hand for 3 times
    int countfight = 0;
  if(vecs[0].y - vecs[15].y > 50 || vecs[0].y - vecs[16].y > 50) {
    println("raise your hand!");
    if ((vecs[15].x < vecs[5].x || vecs[16].x < vecs[2].x) && historyBool[0] == false)
    {
      historyBool[0] = true;
    }
    else if ((vecs[15].x - vecs[5].x > 50 || vecs[16].x - vecs[2].x > 50) && historyBool[0] == true)
    {
      historyBool[0] = false;
      history[0]++;
    }
  }//end of if vecs[15]
  
    // making decision
    if (history[0] == 2)
    {
      history[0] = 0;
      return "happy_2.txt";
    }
    // if foot higher than hand
//    if (vecs[11].y < vecs[16].y || vecs[14].y < vecs[15].y)
//      return "Fight_flyaway.txt";
    
    /**
    // put hand back and punch
    if ((vecs[2].x - vecs[16].x > 100 || vecs[5].x - vecs[15].x > 100) && countfight == 0) {
      countfight = 1;
      println("you fight!");
    }
    if (vecs[2].x < vecs[16].x || vecs[5].x < vecs[15].x) {
      countfight = 0;
    }
    if (countfight == 1) {
      return "Fight_punch.txt";
    }
    */
    else
      return null;
  
  } // end of String chooose
}
class ActionChooserSad extends ActionChooser
{
  public int maxTired = 180;
  public int tired = 0;
  public int sadNum = 0;
  public int getHelpNum = 0;
  public int sadId = 0;
  public int helpId = 0;
  public boolean isBeingHelping = false;
  public ActionChooserSad()
  {
    firstAction = "sad_int.txt";
    sessionName = "Sad";
    bgSvg = "sad-800.svg";
    bgOutline = "sad-outline.svg";
  }
  
  
  
  public String choose(SkeletonData data, SkeletonData showData, Action currentAction)
  {
    if (data == null)
      return null;
      
    PVector[] vecs = data.vectors;
    for (int i = 0; i < 17; i++)
    {
      if (vecs[i] == null)
        if (i == 0)
          vecs[i] = new PVector(500, 500, 2422);
        else
          vecs[i] = vecs[i - 1];
    }
    
    println(sadNum + " " + getHelpNum + " " + tired);
    
    // get results
    if (currentAction.currentIdx == 0) {
      if (tired > 270 || currentAction.actionName.equals("fight_b_surrend.txt") || currentAction.actionName.equals("fight_a_victory.txt"))
        return null;
      if (isBeingHelping && getHelpNum > 5) {
        return "fight_a_victory.txt";
      }
      else if (sadNum > 5)
        return "fight_b_surrend.txt";
      isBeingHelping = false;
      return "sad_loop.txt";
    }
    
    // run away
    if (isBeingHelping && vecs[0].x > 550) {
      return "sad_dont_go.txt";
    }
    
    // positive
    if (vecs[0].x < 500 && !isBeingHelping) {
      if (isClose(vecs[15], showData.vectors[0], 70) || isClose(vecs[16], showData.vectors[0], 70) || // touch head
          //isClose(vecs[15], showData.vectors[2], 40) || isClose(vecs[16], showData.vectors[2], 40) || // shoulder
          //isClose(vecs[15], showData.vectors[5], 40) || isClose(vecs[16], showData.vectors[5], 40) || //shoulder
          isClose(vecs[15], showData.vectors[7], 100) && isClose(vecs[16], showData.vectors[7], 100) // hug
          ) {
         historyBool[0] = true;
         history[0]++;
         if (history[0] >= 70) {
           historyBool[0] = false;
           history[0] = 0;
           isBeingHelping = true;
           tired = 0;
           getHelpNum++;
           float fHitStomach = random(0,3);
           int iHitStomach = PApplet.parseInt(fHitStomach);
           // response randomly
           if (iHitStomach == 0) {
             return "sad_throw_up_hands_frustrated.txt";
           }
           if (iHitStomach == 1) {
             return "sad_one_hand_throw_down.txt";
           }
           if (iHitStomach == 2) {
             return "sad_beat_breast.txt";
           }
         }
         
       }
       else {
         historyBool[0] = false;
         history[0] = 0;
       }
     }
    
    // negative
    
    if (currentAction.actionName.equals("sad_loop.txt")) {
      tired++;
      if (tired > maxTired) {
        sadNum++;
        tired = 0;
        sadId = (sadId + 1)% 3;
        if (sadId == 0)
          return "sad_sigh_head_down.txt";
        else if (sadId == 1)
          return "sad_sigh_hands_down.txt";
        else 
          return "sad_hand_reachout.txt";         
      }
    }
    
    return null;
  } // end of String chooose
  
  private boolean isClose(PVector p1, PVector p2, int distance) {
    if ((p1.x - p2.x) * (p1.x - p2.x) + (p1.y - p2.y) * (p1.y - p2.y) < distance * distance)
      return true;
    return false;     
  }
}
class Background {
  public int maxIdx = 0;
  public int currentIdx = 0;
  public PImage data[];
  
  public Background(String session) {
    currentIdx = 0;
    String prefix = "";
    if (session.equals("Fight")) {
      maxIdx = 142;
      prefix = "boxing";
    }
    else if (session.equals("Dance")) {
      maxIdx = 140;
      prefix = "dance";
    }
    else if (session.equals("Happy")) {
      maxIdx = 134; 
      prefix = "happy";
    }
    else if (session.equals("Sad")) {
      maxIdx = 140;
      prefix = "sad";
    }
      
    data = new PImage[maxIdx + 1];
    for (int i = 0; i < maxIdx + 1; i++) {
      String filepath = dataPath(prefix + "_" + i + ".jpg");
      data[i] = loadImage(filepath);
    }
  }
  
  public PImage getNextFrame() {
    if (currentIdx == maxIdx)
      return data[currentIdx];
    return data[currentIdx++];
  }
}
class SkeletonData
{
  public PVector[] vectors;
  
  public SkeletonData()
  {
    vectors = new PVector[17]; 
  }
  
  public SkeletonData(String line)
  {
    vectors = new PVector[17];
    String[] vecStrs = line.trim().split("\t");
    if (vecStrs.length != 17)
    {
      println("Invalid line!");
      return;
    }
    for (int i = 0; i < 17; i++)
    {
      String[] numStrs = vecStrs[i].split(",");
      float x = Float.parseFloat(numStrs[0]);
      float y = Float.parseFloat(numStrs[1]);
      float z = Float.parseFloat(numStrs[2]);
      vectors[i] = new PVector(x, y, z);
    }
  }
  
  public String toString()
  {
    StringBuilder sb = new StringBuilder();
    for (int i = 0; i < 17; i++)
    {
      if (vectors[i] == null)
      {
        //println("Wrong in " + i + " !!!");
        vectors[i] = new PVector(0, 0, 0);
      }
      sb.append(vectors[i].x + "," + vectors[i].y + "," + vectors[i].z + "\t");
    }
    return sb.toString(); 
  }
}

  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "Working" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
